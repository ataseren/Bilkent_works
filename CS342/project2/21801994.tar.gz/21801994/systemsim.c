#include <stdlib.h>
#include <mqueue.h>
#include <stdio.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <pthread.h>
#include <math.h>
#include <time.h>
#include <sys/time.h>

// global variables
int number_of_process_in_system;
int created_process_so_far = 0;
int processed_so_far = 0;
char *alg;
int time_quantum;
int t1;
int t2;
char *burst_dist;
int burst_length;
int min_burst;
int max_burst;
double p0, p1, p2, pg;
int maxp;
int allp;
int out_mode;
pthread_t tids[1000];

int sleepTimeRR = 1;
pthread_mutex_t RR_lock;

struct timeval baseTime;
struct timeval currentTime;

int processID = 1;
// locks and cvs
pthread_mutex_t gen_lock;
pthread_cond_t gen_cv;

struct queue *readyQueue;
struct queue *finalQueue;

pthread_mutex_t rdy_lock;
pthread_cond_t rdy_cv;

pthread_mutex_t sch_lock;
pthread_cond_t sch_cv;

int io1_count = 0;
pthread_mutex_t io1_lock;
pthread_cond_t io1_cv;

int io2_count = 0;
pthread_mutex_t io2_lock;
pthread_cond_t io2_cv;

// PCB
struct PCB
{
    /* data */
    struct PCB *next;
    int pid;
    pthread_t tid;
    char state[15];
    int next_burst;
    int remainingRR;
    int bursts_so_far;
    int time_in_readylist_so_far;
    int IO_dev1;
    int IO_dev2;
    int arr_time;
    int finish_time;
    int exec_time_so_far;
};

int printTime()
{
    gettimeofday(&currentTime, NULL);
    return (currentTime.tv_sec - baseTime.tv_sec) * 1000 + (currentTime.tv_usec - baseTime.tv_usec) / 1000;
}
// Queue implementation
struct queue
{
    struct PCB *head;
    struct PCB *tail;
    int count; /* number of items in the buffer */
};

struct queue *queue_init()
{
    struct queue *q = (struct queue *)malloc(sizeof(struct queue));
    q->count = 0;
    q->head = NULL;
    q->tail = NULL;
    return q;
}

// this function assumes that space for item is already allocated
void queue_insert(struct queue *q, struct PCB *pcb)
{
    pcb->next = NULL;
    if (q->count == 0)
    {
        q->head = pcb;
        q->tail = pcb;
    }
    else
    {
        q->tail->next = pcb;
        q->tail = pcb;
    }

    q->count++;
}

// this function does not free the item
// it is deleting the item from the list
struct PCB *queue_retrieve(struct queue *q)
{
    struct PCB *pcb;

    if (q->count == 0)
    {
        return NULL;
    }

    pcb = q->head;
    q->head = q->head->next;
    pcb->next = NULL;
    q->count--;

    return pcb;
}

struct PCB *get_first(struct queue *q)
{
    if (q->count == 0)
    {
        return NULL;
    }
    struct PCB *pcb = q->head;

    return pcb;
}

struct PCB *find_shortest(struct queue *q)
{
    struct PCB *shortest_p = q->head;
    struct PCB *temp = q->head;

    if (q->count == 0)
    {
        return NULL;
    }
    if (shortest_p == NULL)
    {
        return NULL;
    }
    for (int a = 0; a < q->count; a++)
    {
        if ((temp != NULL) && (temp->next_burst < shortest_p->next_burst))
        {
            shortest_p = temp;
            temp = temp->next;
        }
    }
    return shortest_p;
}
int real_size(struct queue *q)
{
    int r = 0;
    if (q->head == NULL)
    {
        return r;
    }
    r++;
    struct PCB *temp = q->head;
    while (temp->next != NULL)
    {
        temp = temp->next;
        r++;
    }
    return r;
}

struct PCB *queue_retrieve_shortest(struct queue *q)
{
    if (q->count == 0)
    {
        return NULL;
    }
    if (q->head == NULL)
    {
    }

    struct PCB *shortest = find_shortest(q);
    if (shortest == NULL)
    {
        return NULL;
    }
    else
    {
    }

    struct PCB *prev = NULL;

    for (struct PCB *temp = q->head; temp != NULL; temp = temp->next)
    {
        if (temp == shortest)
        {
            if (temp == q->head)
            {
                q->head = temp->next;
                temp->next = NULL;
                q->count--;
                return temp;
            }
            else
            {
                if (temp == q->tail)
                {
                    prev->next = NULL;
                    q->tail = prev;
                }
                else
                {
                    prev->next = temp->next;
                    temp->next = NULL;
                }
                q->count--;
                return temp;
            }
        }

        if (prev == NULL)
        {
            prev = q->head;
        }
        else
        {
            prev = prev->next;
        }
    }
    return NULL;
}

struct gen_params
{
    int tidIndex;
};

int calculate_next_burst()
{
    int result;
    int max = max_burst;
    int min = min_burst;
    double lambda;
    double u;
    int temp;
    if (strcmp(burst_dist, "fixed") == 0)
    {
        result = burst_length;
    }
    else if (strcmp(burst_dist, "uniform") == 0)
    {
        result = (rand() % (max - min + 1)) + min;
    }
    else if (strcmp(burst_dist, "exponential") == 0)
    {
        lambda = 1 / (double)burst_length;
        do
        {
            u = (double)rand() / (double)RAND_MAX;
            temp = ((-1) * log(u)) / lambda;
        } while (!(temp <= max && temp >= min));
        result = temp;
    }
    return result;
}

void *pro_simulate(void *params)
{
    struct PCB *pcb = (struct PCB *)malloc(sizeof(struct PCB));
    pcb->pid = processID;
    processID++;
    pcb->tid = pthread_self();
    strcpy(pcb->state, "READY");
    pcb->next = NULL;
    pcb->next_burst = calculate_next_burst();
    pcb->remainingRR = pcb->next_burst;
    pcb->bursts_so_far = 0;
    pcb->time_in_readylist_so_far = 0;
    pcb->IO_dev1 = 0;
    pcb->IO_dev2 = 0;
    pcb->arr_time = printTime();
    pcb->finish_time = 0;
    pcb->exec_time_so_far = 0;

    if (out_mode == 3)
    {
        printf("Process %d has been created at time: %d\n", pcb->pid, pcb->arr_time);
    }

    while (1)
    {
        pthread_mutex_lock(&rdy_lock);
        strcpy(pcb->state, "READY");

        if (out_mode == 3)
        {
            printf("Process %d has been added to ready queue at time: %d\n", pcb->pid, printTime());
        }
        queue_insert(readyQueue, pcb);
        pcb->time_in_readylist_so_far++;

        pthread_mutex_unlock(&rdy_lock);
        pthread_mutex_lock(&sch_lock);
        pthread_cond_signal(&sch_cv);
        pthread_mutex_unlock(&sch_lock);
        pthread_mutex_lock(&rdy_lock);
        while (strcmp(pcb->state, "RUNNING") != 0)
        {
            pthread_cond_wait(&rdy_cv, &rdy_lock);
        }
        pthread_mutex_unlock(&rdy_lock);

        if (strcmp(alg, "FCFS") == 0)
        {
            if (out_mode == 2)
            {
                printf("%d %d %s\n", printTime(), pcb->pid, pcb->state);
            }
            if (out_mode == 3)
            {
                printf("Process %d has started to run in cpu at time: %d\n", pcb->pid, printTime());
            }
            usleep(pcb->next_burst * 1000);
            pcb->exec_time_so_far = pcb->exec_time_so_far + pcb->next_burst;

            pthread_mutex_lock(&rdy_lock);
            pcb->bursts_so_far++;
            queue_retrieve(readyQueue);
            pthread_mutex_unlock(&rdy_lock);
            double pa = ((double)rand() / (double)RAND_MAX);
            if ((pa >= 0) && (pa <= p0))
            {
                pthread_mutex_lock(&sch_lock);
                pthread_cond_signal(&sch_cv);
                pthread_mutex_unlock(&sch_lock);
                break;
            }
            else if ((pa > p0) && (pa <= p0 + p1))
            {

                strcpy(pcb->state, "WAITING");

                pthread_mutex_lock(&sch_lock);
                pthread_cond_signal(&sch_cv);
                pthread_mutex_unlock(&sch_lock);

                pthread_mutex_lock(&io1_lock);
                pcb->IO_dev1++;
                io1_count++;
                if (out_mode == 3)
                {
                    printf("Process %d has been added to IO1 queue at time: %d\n", pcb->pid, printTime());
                }
                while (io1_count > 1)
                {
                    pthread_cond_wait(&io1_cv, &io1_lock);
                }
                if (out_mode == 2)
                {
                    printf("%d %d USING DEVICE 1\n", printTime(), pcb->pid);
                }
                usleep(t1 * 1000);
                if (out_mode == 3)
                {
                    printf("Process %d has been using to IO1 queue at time: %d\n", pcb->pid, printTime());
                }
                io1_count--;
                pthread_cond_signal(&io1_cv);
                pthread_mutex_unlock(&io1_lock);

                pthread_mutex_lock(&sch_lock);
                pthread_cond_signal(&sch_cv);
                pthread_mutex_unlock(&sch_lock);
            }
            else if ((pa > p0 + p1) && (pa <= p0 + p1 + p2))
            {
                strcpy(pcb->state, "WAITING");

                pthread_mutex_lock(&sch_lock);
                pthread_cond_signal(&sch_cv);
                pthread_mutex_unlock(&sch_lock);

                pthread_mutex_lock(&io2_lock);
                pcb->IO_dev2++;
                io2_count++;
                if (out_mode == 3)
                {
                    printf("Process %d has been added IO2 queue at time: %d\n", pcb->pid, printTime());
                }
                while (io2_count > 1)
                {
                    pthread_cond_wait(&io2_cv, &io2_lock);
                }
                if (out_mode == 2)
                {
                    printf("%d %d USING DEVICE 2\n", printTime(), pcb->pid);
                }
                usleep(t2 * 1000);
                if (out_mode == 3)
                {
                    printf("Process %d has been using to IO2 queue at time: %d\n", pcb->pid, printTime());
                }
                io2_count--;
                pthread_cond_signal(&io2_cv);
                pthread_mutex_unlock(&io2_lock);

                pthread_mutex_lock(&sch_lock);
                pthread_cond_signal(&sch_cv);
                pthread_mutex_unlock(&sch_lock);
            }
            pcb->next_burst = calculate_next_burst();
        }
        else if (strcmp(alg, "SJF") == 0)
        {
            if (out_mode == 2)
            {
                printf("%d %d %s\n", printTime(), pcb->pid, pcb->state);
            }
            if (out_mode == 3)
            {
                printf("Process %d started to run in cpu at time: %d\n", pcb->pid, printTime());
            }
            usleep(pcb->next_burst * 1000);
            pcb->exec_time_so_far = pcb->exec_time_so_far + pcb->next_burst;
            pthread_mutex_lock(&rdy_lock);
            pcb->bursts_so_far++;
            queue_retrieve_shortest(readyQueue);
            pthread_mutex_unlock(&rdy_lock);
            double pa = ((double)rand() / (double)RAND_MAX);
            if ((pa >= 0) && (pa <= p0))
            {

                pthread_mutex_lock(&sch_lock);
                pthread_cond_signal(&sch_cv);
                pthread_mutex_unlock(&sch_lock);
                break;
            }
            else if ((pa > p0) && (pa <= p0 + p1))
            {
                strcpy(pcb->state, "WAITING");
                pthread_mutex_lock(&sch_lock);
                pthread_cond_signal(&sch_cv);
                pthread_mutex_unlock(&sch_lock);

                pthread_mutex_lock(&io1_lock);
                pcb->IO_dev1++;
                io1_count++;
                if (out_mode == 3)
                {
                    printf("Process %d has been added IO1 queue at time: %d\n", pcb->pid, printTime());
                }
                while (io1_count > 1)
                {
                    pthread_cond_wait(&io1_cv, &io1_lock);
                }
                if (out_mode == 2)
                {
                    printf("%d %d USING DEVICE 1\n", printTime(), pcb->pid);
                }
                usleep(t1 * 1000);
                if (out_mode == 3)
                {
                    printf("Process %d has been using to IO1 queue at time: %d\n", pcb->pid, printTime());
                }
                io1_count--;
                pthread_cond_signal(&io1_cv);
                pthread_mutex_unlock(&io1_lock);

                // signal
                pthread_mutex_lock(&sch_lock);
                pthread_cond_signal(&sch_cv);
                pthread_mutex_unlock(&sch_lock);
            }
            else if ((pa > p0 + p1) && (pa <= p0 + p1 + p2))
            {
                strcpy(pcb->state, "WAITING");

                // signal
                pthread_mutex_lock(&sch_lock);
                pthread_cond_signal(&sch_cv);
                pthread_mutex_unlock(&sch_lock);

                pthread_mutex_lock(&io2_lock);
                pcb->IO_dev2++;
                io2_count++;
                if (out_mode == 3)
                {
                    printf("Process %d has been added IO2 queue at time: %d\n", pcb->pid, printTime());
                }
                while (io2_count > 1)
                {
                    pthread_cond_wait(&io2_cv, &io2_lock);
                }
                if (out_mode == 2)
                {
                    printf("%d %d USING DEVICE 2\n", printTime(), pcb->pid);
                }
                usleep(t2 * 1000);
                if (out_mode == 3)
                {
                    printf("Process %d has been using to IO2 queue at time: %d\n", pcb->pid, printTime());
                }
                io2_count--;
                pthread_cond_signal(&io2_cv);
                pthread_mutex_unlock(&io2_lock);

                // signal
                pthread_mutex_lock(&sch_lock);
                pthread_cond_signal(&sch_cv);
                pthread_mutex_unlock(&sch_lock);
            }
            pcb->next_burst = calculate_next_burst();
        }
        else if (strcmp(alg, "RR") == 0)
        {
            if (pcb->remainingRR <= time_quantum)
            {
                if (out_mode == 2)
                {
                    printf("%d %d %s (FINAL TIME SLICE)\n", printTime(), pcb->pid, pcb->state);
                }
                if (out_mode == 3)
                {
                    printf("Process %d started to run in cpu at time: %d\n", pcb->pid, printTime());
                }
                usleep(pcb->remainingRR * 1000);
                pcb->exec_time_so_far = pcb->exec_time_so_far + pcb->remainingRR;
                pthread_mutex_lock(&rdy_lock);
                pcb->bursts_so_far++;
                queue_retrieve(readyQueue);
                pthread_mutex_unlock(&rdy_lock);
                double pa = ((double)rand() / (double)RAND_MAX);
                if ((pa >= 0) && (pa <= p0))
                {
                    pthread_mutex_lock(&sch_lock);
                    pthread_cond_signal(&sch_cv);
                    pthread_mutex_unlock(&sch_lock);
                    break;
                }
                else if ((pa > p0) && (pa <= p0 + p1))
                {
                    strcpy(pcb->state, "WAITING");
                    pthread_mutex_lock(&sch_lock);
                    pthread_cond_signal(&sch_cv);
                    pthread_mutex_unlock(&sch_lock);

                    pthread_mutex_lock(&io1_lock);
                    pcb->IO_dev1++;
                    io1_count++;
                    if (out_mode == 3)
                    {
                        printf("Process %d has been added IO1 queue at time: %d\n", pcb->pid, printTime());
                    }
                    while (io1_count > 1)
                    {
                        pthread_cond_wait(&io1_cv, &io1_lock);
                    }
                    if (out_mode == 2)
                    {
                        printf("%d %d USING DEVICE 1\n", printTime(), pcb->pid);
                    }
                    usleep(t1 * 1000);
                    if (out_mode == 3)
                    {
                        printf("Process %d has been using to IO1 queue at time: %d\n", pcb->pid, printTime());
                    }
                    io1_count--;
                    pthread_cond_signal(&io1_cv);
                    pthread_mutex_unlock(&io1_lock);

                    pthread_mutex_lock(&sch_lock);
                    pthread_cond_signal(&sch_cv);
                    pthread_mutex_unlock(&sch_lock);
                }
                else if ((pa > p0 + p1) && (pa <= p0 + p1 + p2))
                {
                    strcpy(pcb->state, "WAITING");

                    // signal
                    pthread_mutex_lock(&sch_lock);
                    pthread_cond_signal(&sch_cv);
                    pthread_mutex_unlock(&sch_lock);

                    pthread_mutex_lock(&io2_lock);
                    pcb->IO_dev2++;
                    io2_count++;
                    if (out_mode == 3)
                    {
                        printf("Process %d has been added IO2 queue at time: %d\n", pcb->pid, printTime());
                    }
                    while (io2_count > 1)
                    {
                        pthread_cond_wait(&io2_cv, &io2_lock);
                    }
                    if (out_mode == 2)
                    {
                        printf("%d %d USING DEVICE 2\n", printTime(), pcb->pid);
                    }
                    usleep(t2 * 1000);
                    if (out_mode == 3)
                    {
                        printf("Process %d has been using to IO1 queue at time: %d\n", pcb->pid, printTime());
                    }
                    io2_count--;
                    pthread_cond_signal(&io2_cv);
                    pthread_mutex_unlock(&io2_lock);

                    // signal
                    pthread_mutex_lock(&sch_lock);
                    pthread_cond_signal(&sch_cv);
                    pthread_mutex_unlock(&sch_lock);
                }
                pcb->next_burst = calculate_next_burst();
                pcb->remainingRR = pcb->next_burst;
            }
            else // timeq > RR
            {
                if (out_mode == 2)
                {
                    printf("%d %d %s (QUANTUM)\n", printTime(), pcb->pid, pcb->state);
                }

                usleep(time_quantum * 1000);
                if (out_mode == 3)
                {
                    printf("Process %d expired time quantum at time: %d\n", pcb->pid, printTime());
                }
                pcb->exec_time_so_far = pcb->exec_time_so_far + time_quantum;
                pthread_mutex_lock(&rdy_lock);
                pcb->remainingRR = pcb->remainingRR - time_quantum;
                queue_retrieve(readyQueue);
                pthread_mutex_unlock(&rdy_lock);

                pthread_mutex_lock(&sch_lock);
                pthread_cond_signal(&sch_cv);
                pthread_mutex_unlock(&sch_lock);

                pthread_mutex_lock(&sch_lock);
                pthread_cond_signal(&sch_cv);
                pthread_mutex_unlock(&sch_lock);
            }
        }
        pthread_mutex_lock(&rdy_lock);
        pthread_cond_broadcast(&rdy_cv);
        pthread_mutex_unlock(&rdy_lock);
    }
    pthread_mutex_lock(&rdy_lock);
    pthread_cond_broadcast(&rdy_cv);
    pthread_mutex_unlock(&rdy_lock);
    pthread_mutex_lock(&sch_lock);
    pthread_cond_signal(&sch_cv);
    pthread_mutex_unlock(&sch_lock);

    pthread_mutex_lock(&gen_lock);
    processed_so_far++;
    number_of_process_in_system--;
    pthread_cond_broadcast(&gen_cv);
    pthread_mutex_unlock(&gen_lock);

    pthread_mutex_lock(&sch_lock);
    pthread_cond_signal(&sch_cv);
    pthread_mutex_unlock(&sch_lock);

    pcb->finish_time = printTime();
    if (out_mode == 3)
    {
        printf("Process %d finished execution and leaving system at time: %d\n", pcb->pid, printTime());
    }
    queue_insert(finalQueue, pcb);
    pthread_exit(NULL);
}

void *generate(void *gen_params)
{

    pthread_mutex_init(&gen_lock, NULL);
    pthread_cond_init(&gen_cv, NULL);

    int i;
    struct gen_params arg;

    for (i = 0; i < 10 && i < maxp; i++)
    {

        pthread_mutex_lock(&gen_lock);

        while (number_of_process_in_system == maxp)
        {
            pthread_cond_wait(&gen_cv, &gen_lock);
        }
        int ret = pthread_create(&tids[i], NULL, pro_simulate, (void *)&(arg));
        if (ret != 0)
        {
            printf("Generator: thread create failed\n");
            exit(1);
        }

        created_process_so_far++;
        number_of_process_in_system++;
        pthread_mutex_unlock(&gen_lock);

        pthread_mutex_lock(&sch_lock);
        pthread_cond_signal(&sch_cv);
        pthread_mutex_unlock(&sch_lock);
    }

    while (created_process_so_far < allp)
    {
        usleep(5000);
        pthread_mutex_lock(&gen_lock);
        while (number_of_process_in_system == maxp)
        {
            pthread_cond_wait(&gen_cv, &gen_lock);
        }
        if (((double)rand() / (double)RAND_MAX) < pg)
        {
            int ret = pthread_create(&tids[i], NULL, pro_simulate, NULL);
            if (ret != 0)
            {
                printf("Generator: thread create failed\n");
                exit(1);
            }
            created_process_so_far++;
            number_of_process_in_system++;
            i++;
        }
        pthread_mutex_unlock(&gen_lock);
        pthread_mutex_lock(&sch_lock);
        pthread_cond_signal(&sch_cv);
        pthread_mutex_unlock(&sch_lock);
    }

    pthread_mutex_destroy(&gen_lock);
    pthread_cond_destroy(&gen_cv);
    pthread_exit(NULL);
}

void *scheduler(void *sch_params)
{
    pthread_mutex_init(&sch_lock, NULL);
    pthread_cond_init(&sch_cv, NULL);

    while ((created_process_so_far < allp) || number_of_process_in_system > 0 || readyQueue->count > 0 || io1_count > 0 || io2_count > 0 || processed_so_far < allp)
    {
        pthread_mutex_lock(&sch_lock);
        pthread_cond_wait(&sch_cv, &sch_lock);
        pthread_mutex_unlock(&sch_lock);
        if (strcmp(alg, "FCFS") == 0)
        {

            pthread_mutex_lock(&rdy_lock);
            if (get_first(readyQueue) != NULL)
            {
                if (out_mode == 3)
                {
                    printf("Process %d has been selected to run at time: %d\n", get_first(readyQueue)->pid, printTime());
                }
                strcpy(get_first(readyQueue)->state, "RUNNING");
                pthread_cond_broadcast(&rdy_cv);
            }
            else
            {
                pthread_cond_broadcast(&rdy_cv);
            }
            pthread_mutex_unlock(&rdy_lock);
        }
        else if (strcmp(alg, "SJF") == 0)
        {

            pthread_mutex_lock(&rdy_lock);

            if (find_shortest(readyQueue) != NULL)
            {
                if (out_mode == 3)
                {
                    printf("Process %d has been selected to run at time: %d\n", find_shortest(readyQueue)->pid, printTime());
                }
                strcpy(find_shortest(readyQueue)->state, "RUNNING");
                pthread_cond_broadcast(&rdy_cv);
            }
            else
            {
                pthread_cond_broadcast(&rdy_cv);
            }
            pthread_mutex_unlock(&rdy_lock);
        }
        else if (strcmp(alg, "RR") == 0)
        {
            pthread_mutex_lock(&rdy_lock);
            if (get_first(readyQueue) != NULL)
            {
                if (out_mode == 3)
                {
                    printf("Process %d has been selected to run at time: %d\n", get_first(readyQueue)->pid, printTime());
                }
                strcpy(get_first(readyQueue)->state, "RUNNING");
                pthread_cond_broadcast(&rdy_cv);
            }
            else
            {
                pthread_cond_broadcast(&rdy_cv);
            }
            pthread_mutex_unlock(&rdy_lock);
        }
    }
    pthread_mutex_lock(&rdy_lock);
    pthread_cond_broadcast(&rdy_cv);
    pthread_mutex_unlock(&rdy_lock);

    pthread_exit(NULL);
}

int main(int argc, char **argv)
{
    gettimeofday(&baseTime, NULL);
    readyQueue = queue_init();
    finalQueue = queue_init();

    pthread_mutex_init(&rdy_lock, NULL);
    pthread_cond_init(&rdy_cv, NULL);

    pthread_mutex_init(&io1_lock, NULL);
    pthread_cond_init(&io1_cv, NULL);

    pthread_mutex_init(&io2_lock, NULL);
    pthread_cond_init(&io2_cv, NULL);

    pthread_mutex_init(&RR_lock, NULL);

    number_of_process_in_system = 0;
    alg = argv[1];
    if (strcmp(argv[2], "INF") == 0)
    {
        // INF not used
    }
    else
    {
        time_quantum = atof(argv[2]);
    }
    t1 = atoi(argv[3]);
    t2 = atoi(argv[4]);
    burst_dist = argv[5];
    burst_length = atoi(argv[6]);
    min_burst = atoi(argv[7]);
    max_burst = atoi(argv[8]);
    p0 = atof(argv[9]);
    p1 = atof(argv[10]);
    p2 = atof(argv[11]);
    pg = atof(argv[12]);
    maxp = atoi(argv[13]);
    allp = atoi(argv[14]);
    out_mode = atoi(argv[15]);

    pthread_t thread_generator_id; /*thread ids*/
    pthread_t cpu_scheduler_id;

    int ret;
    char *retmsg;
    srand(time(NULL));

    // Thread generator thread
    ret = pthread_create(&(thread_generator_id), NULL, generate, NULL);

    if (ret != 0)
    {
        printf("Main: thread create failed \n");
        exit(1);
    }

    // CPU scheduler thread
    ret = pthread_create(&(cpu_scheduler_id), NULL, scheduler, NULL);

    if (ret != 0)
    {
        printf("Main: thread create failed \n");
        exit(1);
    }

    ret = pthread_join(thread_generator_id, (void **)&retmsg);
    if (ret != 0)
    {
        printf("Main: thread join failed \n");
        exit(1);
    }

    ret = pthread_join(cpu_scheduler_id, (void **)&retmsg);
    if (ret != 0)
    {
        printf("thread join failed \n");
        exit(1);
    }

    for (int i = 0; i < allp; i++)
    {
        ret = pthread_join(tids[i], (void **)&retmsg);
        if (ret != 0)
        {
            printf("Main: thread join failed \n");
            exit(1);
        }

        // free(retmsg);
    }

    printf("pid   arv  dept  cpu  waitr  turna  n-bursts  n-d1  n-d2\n");
    for (struct PCB *temp = finalQueue->head; temp != NULL; temp = temp->next)
    {
        printf("%3d  %4d  %4d  %3d  %5d  %5d  %8d  %4d  %4d\n", temp->pid, temp->arr_time, temp->finish_time, temp->exec_time_so_far,
               (temp->finish_time - temp->arr_time - temp->exec_time_so_far), (temp->finish_time - temp->arr_time),
               temp->bursts_so_far, temp->IO_dev1, temp->IO_dev2);
    }

    pthread_mutex_destroy(&rdy_lock);
    pthread_cond_destroy(&rdy_cv);

    pthread_mutex_destroy(&sch_lock);
    pthread_cond_destroy(&sch_cv);

    pthread_mutex_destroy(&io1_lock);
    pthread_cond_destroy(&io1_cv);

    pthread_mutex_destroy(&io2_lock);
    pthread_cond_destroy(&io2_cv);
}
