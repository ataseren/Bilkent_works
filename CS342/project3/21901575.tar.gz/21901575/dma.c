#include <stdlib.h>
#include <mqueue.h>
#include <stdio.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <pthread.h>
#include <math.h>
#include <sys/mman.h>

#include "dma.h"

//global variables
void* bitmapptr;
int freeAreaStartIndex;
int bitMapSizeAsBytes;
int internalFragmentation = 0;
int segmentSize;
int bitMapBytesInBitMap;

pthread_mutex_t myLock;

int dma_init (int m)
{
    pthread_mutex_init(&myLock, NULL);
    // check m between 14 and 22 inclusive
    if (m < 14 || m > 22)
    {
        printf("m must be between 14 and 22 inclusive\n");
        printf("dma_init failed\n");
        return -1;
    }

    segmentSize = pow(2, m);
    //allocate memory using mmap
    bitmapptr = mmap(NULL, (size_t)segmentSize, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (bitmapptr == MAP_FAILED)
    {
        printf("mmap failed\n");
        return -1;
    }

    //initialize bitmap
    bitMapSizeAsBytes = segmentSize / 64; 
    bitMapBytesInBitMap = bitMapSizeAsBytes / 64; 
    int reservedBytesEnd = bitMapBytesInBitMap + 4;
    int byteIndex;

    //encode bitmap as used
    ((unsigned char*)bitmapptr)[0] = 0x40;

    for (byteIndex = 1; byteIndex < bitMapBytesInBitMap; byteIndex++)
    {
        ((unsigned char*)bitmapptr)[byteIndex] = 0x00;
    }

    ((unsigned char*)bitmapptr)[byteIndex] = 0x40;
    byteIndex++;
    //encode reserved as used
    for (; byteIndex < reservedBytesEnd; byteIndex++)
    {
        ((unsigned char*)bitmapptr)[byteIndex] = 0x00;
    }

    //encode remaining as unused
    for (; byteIndex < bitMapSizeAsBytes; byteIndex++)
    {
        ((unsigned char*)bitmapptr)[byteIndex] = 0xff;
    }
    
    return 0;
}

void*dma_alloc(int size)
{
    //acquire lock
    pthread_mutex_lock(&myLock);
    int byteIndex = 0;
    int foundBitsSoFar = 0;
    //find smallest multiple of 16 that is greater than or equal to size
    int requiredBits = 2 * (int)ceil(size / 16.0);
    internalFragmentation += requiredBits * 8 - size;

    if (requiredBits / 8 > bitMapSizeAsBytes)
    {
        printf("size is too big\n");
        pthread_mutex_unlock(&myLock);
        return NULL;
    }
    int allocStartByte;
    int allocStartByteRest;
    int allocByteIndex;
    int allocByteIndexRest;
    int allocBitsleft = requiredBits;
    unsigned char afterShift;
    unsigned char value;

    // consider cases like 0111
    //find first free block
    while(byteIndex < bitMapSizeAsBytes)
    {
        value = ((unsigned char*)bitmapptr)[byteIndex];
        
        for (int i = 0; i < 4; i++)
        {
            afterShift = value << (i*2);
            if( (afterShift & 0xc0) == 0xc0)
            {   
                foundBitsSoFar = foundBitsSoFar + 2;
                if(foundBitsSoFar == 2)
                {
                    allocStartByte = byteIndex;
                    allocStartByteRest = byteIndex;
                    allocByteIndex = i;
                }
                if(foundBitsSoFar == requiredBits)
                {
                    break;
                }
            }
            else{
                allocStartByte = 0;
                allocStartByteRest = 0;
                allocByteIndex = 0;
                foundBitsSoFar = 0;
            }
        }
        if(foundBitsSoFar == requiredBits)
        {
            break;
        }
        byteIndex++;

    }

    if (foundBitsSoFar < requiredBits)
    {   
        printf("a block that is large enough could not be found\n");
        pthread_mutex_unlock(&myLock);
        return (void*)NULL;
    }

    allocByteIndexRest = allocByteIndex + 1;
    switch (allocByteIndex)
    {
    case 0:
        ((unsigned char*)bitmapptr)[allocStartByte] = ((unsigned char*)bitmapptr)[allocStartByte] & 0x7f;//01111111
        break;
    case 1: 
        ((unsigned char*)bitmapptr)[allocStartByte] = ((unsigned char*)bitmapptr)[allocStartByte] & 0xdf; //11011111
        break;
    case 2:
        ((unsigned char*)bitmapptr)[allocStartByte] = ((unsigned char*)bitmapptr)[allocStartByte] & 0xf7; //11110111
        break;
    case 3:
        ((unsigned char*)bitmapptr)[allocStartByte] = ((unsigned char*)bitmapptr)[allocStartByte] & 0xfd; //11111101
        break;
    default:
        break;
    }

    allocBitsleft = allocBitsleft -2;

    while(allocBitsleft != 0)
    {
        if(allocByteIndexRest > 3) 
        {
            allocByteIndexRest = 0;
            allocStartByteRest++;
        }
        for (; allocByteIndexRest < 4; allocByteIndexRest++)
        {
            if(allocBitsleft == 0){break;}
            switch (allocByteIndexRest)
            {
            case 0:
                ((unsigned char*)bitmapptr)[allocStartByteRest] = ((unsigned char*)bitmapptr)[allocStartByteRest] & 0x3f; //00111111
                break;
            case 1:
                ((unsigned char*)bitmapptr)[allocStartByteRest] = ((unsigned char*)bitmapptr)[allocStartByteRest] & 0xcf; //11001111
                break;
            case 2:
                ((unsigned char*)bitmapptr)[allocStartByteRest] = ((unsigned char*)bitmapptr)[allocStartByteRest] & 0xf3; //11110011
                break;
            case 3:
                ((unsigned char*)bitmapptr)[allocStartByteRest] = ((unsigned char*)bitmapptr)[allocStartByteRest] & 0xfc; //11111100
                break;
            default:
                break;
            }
            allocBitsleft = allocBitsleft - 2;
        } 
    }
    pthread_mutex_unlock(&myLock);
    //int bitIndex = allocStartByte * 8 + allocByteIndex * 2;
    //printf("ptr offset: %d\n", allocStartByte * 64 + allocByteIndex * 16);
    
    return (void*)((bitmapptr + (allocStartByte * 64 + allocByteIndex * 16) ));
    //return bitmapptr + (allocStartByte * 8) + (allocByteIndex * 2);
}

void dma_free (void *p)
{
    // check if pointer is valid
    if (p == NULL)
    {
        printf("pointer is null\n");
        return;
    }
    // check if pointer is in the range of the bitmap
    if (p < bitmapptr + bitMapBytesInBitMap || p > bitmapptr + segmentSize)
    {
        printf("pointer is not in the range of the bitmap\n");
        return;
    }

    //acquire lock
    pthread_mutex_lock(&myLock);
    int allocByteIndex = ((p - bitmapptr)%64)/16;
    int allocStartByte = (p - bitmapptr - allocByteIndex * 16)/64;
    int deallocByteIndex = allocByteIndex;
    int deallocByteStart = allocStartByte;
    int deallocBitsLeft = 0;
    unsigned char afterShift;

    unsigned char value = ((unsigned char*)bitmapptr)[deallocByteStart];
    
    afterShift = value << (deallocByteIndex*2);

    if( (afterShift & 0xc0) == 0x40)
    {
        deallocBitsLeft = deallocBitsLeft + 2;
        deallocByteIndex++;
    }
    else
    {
        printf("freeing error happened\n");
        pthread_mutex_unlock(&myLock);
        return;
    }
    int sizeDone = 0;
    while(deallocByteStart < bitMapSizeAsBytes)
    {   
        if(deallocByteIndex > 3) 
        {
            deallocByteIndex = 0;
            deallocByteStart++;
        }
        for (; deallocByteIndex < 4; deallocByteIndex++)
        {
            switch (deallocByteIndex)
            {
            case 0: 
                if( (((unsigned char*)bitmapptr)[deallocByteStart] & 0xc0) == 0x00)
                {
                    deallocBitsLeft = deallocBitsLeft + 2;
                }
                else
                {
                    sizeDone = 1;
                }
                break;
            case 1:
                if( (((unsigned char*)bitmapptr)[deallocByteStart] & 0x30) == 0x00)
                {
                    deallocBitsLeft = deallocBitsLeft + 2;
                }
                else
                {
                    sizeDone = 1;
                }
                break;
            case 2:
                if( (((unsigned char*)bitmapptr)[deallocByteStart] & 0x0c) == 0x00)
                {
                    deallocBitsLeft = deallocBitsLeft + 2;
                }
                else
                {
                    sizeDone = 1;
                }
                break;
            case 3:
                if( (((unsigned char*)bitmapptr)[deallocByteStart] & 0x03) == 0x00)
                {
                    deallocBitsLeft = deallocBitsLeft + 2;
                }
                else
                {
                    sizeDone = 1;
                }
                break;
            default:
                break;
            }
            if(sizeDone == 1)
            {
                break;
            }
        }

        if(sizeDone == 1)
        {
            break;
        }
    }

    deallocByteIndex = allocByteIndex;
    deallocByteStart = allocStartByte;
    while(deallocBitsLeft != 0)
    {
        if(deallocByteIndex > 3) 
        {
            deallocByteIndex = 0;
            deallocByteStart++;
        }
        for (; deallocByteIndex < 4; deallocByteIndex++)
        {
            if(deallocBitsLeft == 0){break;}
            switch (deallocByteIndex)
            {
            case 0:
                ((unsigned char*)bitmapptr)[deallocByteStart] = ((unsigned char*)bitmapptr)[deallocByteStart] | 0xc0;
                deallocBitsLeft = deallocBitsLeft - 2;
                break;
            case 1:
                ((unsigned char*)bitmapptr)[deallocByteStart] = ((unsigned char*)bitmapptr)[deallocByteStart] | 0x30;
                deallocBitsLeft = deallocBitsLeft - 2;
                break;
            case 2:
                ((unsigned char*)bitmapptr)[deallocByteStart] = ((unsigned char*)bitmapptr)[deallocByteStart] | 0x0c;
                deallocBitsLeft = deallocBitsLeft - 2;
                break;
            case 3:
                ((unsigned char*)bitmapptr)[deallocByteStart] = ((unsigned char*)bitmapptr)[deallocByteStart] | 0x03;
                deallocBitsLeft = deallocBitsLeft - 2;
                break;
            default:
                break;
            }

        }
    }
    pthread_mutex_unlock(&myLock);
}

void dma_print_page(int pno)
{
    pthread_mutex_lock(&myLock);
    //pagesize = 4096 Byte = 2^12 Byte = 2^9 words = Represented by 2^9 bits = 2^ 6 bytes
    //int pageSize = pow(2, 12);
    int representedSoFar = 0;
    int startIndex = pno*4096;
    for(int i = startIndex ; i < startIndex + 4096; i++)
    {
        printf("%02x", ((unsigned char*)bitmapptr)[i]);
        representedSoFar += 2;
        if(representedSoFar == 64)
        {
            printf("\n");
            representedSoFar = 0;
        }
    }
    pthread_mutex_unlock(&myLock);
}

void dma_print_bitmap()
{
    pthread_mutex_lock(&myLock);
    int byteIndex = 0;
    while (byteIndex < bitMapSizeAsBytes)
    {
        for (int a = 0; a < 8; a++)
        {
            for (int i = 7; 0 <= i; i--) 
            {
                printf("%c", (((unsigned char*)bitmapptr)[byteIndex]& (1 << i)) ? '1' : '0');
            }
            printf(" ");
            byteIndex++;
        }
        printf("\n");
    }
    pthread_mutex_unlock(&myLock);
}

void dma_print_blocks()
{
    pthread_mutex_lock(&myLock);
    int byteIndex = 0;
    char* allocated = "C";
    int size = 0;
    long int address;
    unsigned char afterShift;
    while (byteIndex < bitMapSizeAsBytes)
    {
        unsigned char value = ((unsigned char*)bitmapptr)[byteIndex];
        for (int bitIndex = 0; bitIndex < 4; bitIndex++)
        {
            afterShift = value << (bitIndex*2);
            if( (afterShift & 0xc0) == 0x40)
            {
                if(strcmp("F",allocated) == 0 || strcmp(allocated,"A") == 0)
                {
                    printf("%s, 0x%016lx, 0x%x (%d)\n", allocated, address, size, size);
                    size = 0;
                }
                address = (long int)(bitmapptr + (byteIndex * 8) + (bitIndex * 2));
                allocated = "A";
                size = 16;
            }
            else if((afterShift & 0xc0) == 0x00)
            {
                size = size + 16;
            }
            else if((afterShift & 0xc0) == 0xc0)
            {
                if(strcmp(allocated,"A") == 0)
                {
                    printf("%s, 0x%016lx, 0x%x (%d)\n", allocated, address, size, size);
                    size = 0;
                    address = (long int)(bitmapptr + (byteIndex * 8) + (bitIndex * 2));
                }
                allocated = "F";
                size = size + 16;
            }

        }
        byteIndex++;
    }
    printf("%s, 0x%016lx, 0x%x (%d)\n", allocated, address, size, size);
    pthread_mutex_unlock(&myLock);
}

int dma_give_intfrag(){
    pthread_mutex_lock(&myLock);
    int result = internalFragmentation;
    pthread_mutex_unlock(&myLock);
    return result;
}