#include <stdlib.h>
#include <mqueue.h>
#include <stdio.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <pthread.h>
#include <math.h>
#include <sys/mman.h>
#include <time.h>
#include <sys/time.h>
#include "dma.h"


struct timeval baseTime;
struct timeval currentTime;

int printTime()
{
    gettimeofday(&currentTime, NULL);
    return (currentTime.tv_sec - baseTime.tv_sec) * 1000000 + (currentTime.tv_usec - baseTime.tv_usec);
}

int main (int argc, char ** argv)
{
    srand(time(NULL));
    void *p1;
    void *p2;
    void *p3;
    void *p4;
    void *p5;

    int ret;
    ret = dma_init (16); // create a segment of 64KB
    if (ret != 0) {
        printf ("something was wrong\n");
        exit(1);
    }

    
    //create an array with 5 elements and initialize elements to 0
    int array[7];
    for(int i = 0; i < 10; i++){
        array[i] = 0;
    }

    //fill the array with random integers between 5000 and 15000
    for(int i = 0; i < 7; i++){
        array[i] = rand() % 10000 + 5000;
    }

    //print sum of elements in array
    int sum = 0;
    for(int i = 0; i < 5; i++){
        sum += array[i];
    }

    // start timer
    gettimeofday(&baseTime, NULL);
    printf("sum of total size desired to be allocated : %d\n", sum);
    p1 = dma_alloc(array[0]);
    if(p1 == NULL){printf("alloc error\n");}
    else{
        printf("%d byte allocation request successfully done \n", array[0]);
    }

    p2 = dma_alloc(array[1]);
    if(p2 == NULL){printf("alloc error\n");}
    else{
        printf("%d byte allocation request successfully done \n", array[1]);
    }

    p3 = dma_alloc(array[2]);
    if(p3 == NULL){printf("alloc error\n");}
    else{
        printf("%d byte allocation request successfully done \n", array[2]);
    }

    p4 = dma_alloc(array[3]);
    if(p4 == NULL){printf("alloc error\n");}
    else{
        printf("%d byte allocation request successfully done \n", array[3]);
    }

    p5 = dma_alloc(array[4]);
    if(p5 == NULL){printf("alloc error\n");}
    else{
        printf("%d byte allocation request successfully done \n", array[4]);
    }
    printf("total allocaton time of 5 random amounts between 5000 and 15000 bytes in microseconds: %d\n", printTime());

    printf("blocks after allocation:\n");
    dma_print_blocks();


    printf("internal fragmentation amount: %d\n",dma_give_intfrag());
    //start timer
    gettimeofday(&baseTime, NULL);

    if(p2 != NULL){dma_free(p2);}
    else{printf("p2 was null\n");}
    if(p4 != NULL){dma_free(p4);}
    else{printf("p4 was null\n");}

    //end timer
    printf("p2 and p4 are freed in microseconds: %d\n",printTime());

    printf("blocks after freeing p2 and p4:\n");
    dma_print_blocks();

    //start timer
    gettimeofday(&baseTime, NULL);
    // Now lets try to allocate 2 new amounts of memory for p2 and p4
    p2 = dma_alloc(array[5]);
    if(p2 == NULL){printf("Allocation with %d bytes couldn't fit (alloc error)\n", array[5]);}
    else{
        printf("%d byte allocation request successfully done \n", array[5]);
    }
    p4 = dma_alloc(array[6]);
    if(p4 == NULL){printf("Allocation with %d bytes couldn't fit (alloc error)\n", array[6]);}
    else{
        printf("%d byte allocation request successfully done \n", array[6]);
    }
    printf("total reallocaton time of 2 new random amounts between 5000 and 15000 bytes for p2 and p4 in microseconds: %d\n", printTime());

    //print blocks
    printf("blocks after reallocation of p2 and p4:\n");
    dma_print_blocks();

    //start timer
    gettimeofday(&baseTime, NULL);

    if(p1 != NULL){dma_free(p1);}
    else{printf("p1 was null\n");}
    if(p2 != NULL){dma_free(p2);}
    else{printf("p2 was null\n");}
    if(p3 != NULL){dma_free(p3);}
    else{printf("p3 was null\n");}
    if(p4 != NULL){dma_free(p4);}
    else{printf("p4 was null\n");}
    if(p5 != NULL){dma_free(p5);}
    else{printf("p5 was null\n");}

    //end timer
    printf("All allocations are freed in microseconds: %d\n",printTime());

    printf("blocks after freeing:\n");
    dma_print_blocks();

    //print internal fragmentation after realloaction and freeing
    printf("internal fragmentation amount after reallocation and freeing: %d\n",dma_give_intfrag());
    
    
}