#include <sys/types.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/wait.h>
#include <mqueue.h>
#include <time.h>
#include <sys/time.h>

//struct for properties of histogram
struct histogram {
    int intervalcount;
    int intervalwidth;
    int intervalstart;
};

//struct for carrying arrays (mostly histogram data) on message queue
struct num {
    int id;
    int data[1000];
};

//function that prints given array, for testing purposes
void printarray(int array[], int count)
{
    for (int i = 0; i < count; i++) {
        printf("%d ", array[i]);
    }
}

int main(int argc,char* argv[])
{
    //variables for experiments
    /*
    struct timeval begin;
	struct timeval end;
    */
    
    
    
    
    //message queue elements to receive histogram properties
    mqd_t mq;
	struct mq_attr mq_attr;
	struct histogram *histptr;
    struct num num;
    struct num *receivenum;
	int r;
	char *bufptr;
	int buflen;

    for (int i = 0; i < 1000; i++)
    {
        num.data[i] = 0;
    }
    
    
	mq = mq_open("/clienttoserver", O_RDWR | O_CREAT, 0666, NULL);
	if (mq == -1) {
		perror("can not create msg queue\n");
		exit(1);
	}


	mq_getattr(mq, &mq_attr);


	// allocate large enough space for the buffer to store an incoming message
    buflen = mq_attr.mq_msgsize;
	bufptr = (char *) malloc(buflen);

	r = mq_receive(mq, (char *) bufptr, buflen, NULL);
	if (r == -1) {
		perror("mq_receive failed\n");
		exit(1);
	}
	
    //data extracted from message queue
    histptr = (struct histogram *) bufptr;

    int intervalcount = histptr->intervalcount;
    int intervalwidth = histptr->intervalwidth;
    int intervalstart = histptr->intervalstart;


	free(bufptr);

    //to set data for intervals
    int interval[intervalcount + 1];
    int index = 0;

    for (int i = intervalstart; i <= intervalstart + intervalwidth*5; i = i + intervalwidth)
    {
        interval[index] = i;
        index++;
    }

    
    //process creation
    pid_t  n; // stores process id

    mqd_t mqparent;
	struct mq_attr mq_attr2;
	int r2;
	char *bufptr2;
	int buflen2;
    
    //receiver message queue for parent process
	mqparent = mq_open("/childtoparent", O_RDWR | O_CREAT, 0666, NULL);
	if (mqparent == -1) {
		perror("can not create msg queue\n");
		exit(1);
	}

	mq_getattr(mqparent, &mq_attr2);

	//allocate large enough space for the buffer to store an incoming message
    buflen2 = mq_attr.mq_msgsize;
	bufptr2 = (char *) malloc(buflen2);

    //sender message queue for child processes
    mqd_t mqchild;
    int error;
	mqchild = mq_open("/childtoparent", O_RDWR);

	if (mqchild == -1) {
		perror("can not open child msg queue in server\n");
		exit(1);
	}

    int filecount = atoi(argv[1]);

    //built-in function for experiments
    //gettimeofday(&begin, NULL);
    for (int i = 2; i <= filecount + 1; i++) 
    {
        n = fork();
        if (n == 0) 
        {
            // this part executed by child process
            char *filename = argv[i];
            FILE *fp = fopen(filename, "r");

            if (fp == NULL)
            {
                printf("Error: could not open file %s", filename);
                return 1;
            }
            char buffer[50];
            while (fgets(buffer, 50, fp))
            {
                int a = atoi(buffer);
                for (int x = 0; x <= intervalcount; x++)
                {

                    if(a >= interval[x] && a < interval[x+1])
                    {   
                        //array element for corresponding interval is incremented
                        num.data[x] = num.data[x] + 1;
                        break;
                    }
                }
            }
            // close the file
            fclose(fp);
            error = mq_send(mqchild, (char *) &num, sizeof(struct num), 0);
            if (error == -1) 
            {
                perror("mq_send failed\n");
                exit(1);
            }
            exit(0); //child is terminating
        }
        else 
        {
            // parent process
        }
    }

    

    //array to carry final result
    int result[intervalcount];
    for (int i = 0; i < intervalcount; i++)
    {
        result[i] = 0;
    }

    for(int a = 0; a < filecount; a++)
    {
        //receiving histogram data from child processes
        r2 = mq_receive(mqparent, (char *) bufptr2, buflen2, NULL);
        if (r2 == -1) {
            perror("mq_receive failed\n");
            exit(1);
	    }
        receivenum = (struct num *) bufptr2;

        for (int a = 0; a < intervalcount; a++)
        {
            result[a] = result[a] + receivenum->data[a];
        } 

    }

	free(bufptr2);
	mq_close(mqparent);

    mq_close(mqchild);

    mqd_t mqfinal;
	struct num numfinal;

    for(int i = 0; i<intervalcount;i++)
    {
        numfinal.data[i] = result[i];
    }

	mqfinal = mq_open("/servertoclient", O_RDWR);

	if (mqfinal == -1) {
		perror("can not open msg queue\n");
		exit(1);
	}

    //sending histogram result to client
	error = mq_send(mqfinal, (char *) &numfinal, sizeof(struct num), 0);

	if (error == -1) {
		perror("mq_send failed\n");
		exit(1);
	}

    mq_getattr(mq, &mq_attr);


	// allocate large enough space for the buffer to store an incoming message
    buflen = mq_attr.mq_msgsize;
	bufptr = (char *) malloc(buflen);

	r = mq_receive(mq, (char *) bufptr, buflen, NULL);
	if (r == -1) {
		perror("mq_receive failed\n");
		exit(1);
	}

    receivenum = (struct num *) bufptr;

    free(bufptr);

    //termination trigger
    //shuts down message queues and waits for child processes to be terminated
    if(receivenum->data[0] == -1)
    {
        // wait for all children to terminate
        for (int a = 2; a <= filecount + 1; a++)
        {
            wait(NULL); 
        }
        //built-in function for experiments
        //gettimeofday(&end, NULL);
        //message queue shut downs
        mq_close(mq);
        mq_close(mqparent);
        mq_close(mqchild);
        mq_close(mqfinal);

    }
    else
    { 
        printf("Queue shutdown and child termination failed!!!");
    }

    //to print experiment results

    /*
    printf("Execution took %ld seconds and %ld microseconds\n", end.tv_sec - begin.tv_sec, 
    end.tv_sec - begin.tv_sec+ end.tv_usec - begin.tv_usec);
    */
    
    

    return 0;
}