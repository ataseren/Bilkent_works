


#define SERVER_PORT 5601
#define SERVER_IP "127.0.0.1"
