


Run consumer first.

You can run consumer in one window  (terminal) and producer in another window (terminal).

In this way, you can see the communication happeninig. Producer sending and Consumer receiving messages. 
