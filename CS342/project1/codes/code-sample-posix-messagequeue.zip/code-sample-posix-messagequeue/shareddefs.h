

struct item {
	int id;
	char astr[64];
};


#define MQNAME "/justaname"
