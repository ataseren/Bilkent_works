<?php
include('config.php');
session_start();
function logIn($mysqli)
{
    $username = $_POST['username'];
    $id = $POST['id'];
    $query = "select * from student where sname = '$username' and sid = '$id'";
    if($result = $mysqli->query(&query)){
        
    }
}

?>