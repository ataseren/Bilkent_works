<?php

session_start();
 

if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true){
    header("location: welcome.php");
    exit;
}
 
require_once "config.php";
 
// Define variables and initialize with empty values
$username = ""; 
$password = "";
$username_err = "";
$password_err = "";
$login_err = "Invalid username or password.";
// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
 
    // Check if username is empty
    if(empty(trim($_POST["username"]))){
        $username_err = "Enter your username here.";
    } else{
        $username = trim($_POST["username"]);
    }
    
    // Check if password is empty
    if(empty(trim($_POST["password"]))){
        $password_err = "Enter your ID (password) here.";
    } else{
        $password = trim($_POST["password"]);
    }
    
    // Validate credentials
    if(empty($username_err) && empty($password_err)){
        // Prepare a select statement
        $loginQuery = mysqli_query($connection, "SELECT sname FROM student WHERE LOWER(sid) = '" . strtolower( $_POST['password']) . "'");
        if(!$loginQuery){
          $_SESSION["error"] = $login_err;
          header("location: index.php");
          exit;
        }
        else{
          $record = mysqli_fetch_array($loginQuery);
          if($record["sname"] == $_POST["username"]){
            $_SESSION["loggedin"] = true;
            $_SESSION["sname"] = $_POST["username"];
            $_SESSION["sid"] = $_POST["password"];
            header("location: welcome.php");
            exit;
          }
          else{
            $_SESSION["error"] = $login_err;
            header("location: index.php");
            exit;
          }
        }
    }
    
    // Close connection
    mysqli_close($connection);
}
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body{ font: 14px sans-serif; }
        .wrapper{ width: 360px; padding: 20px; }
    </style>
</head>
<body>
    <div class="wrapper">
        <h2>Login</h2>
        <p>Please fill in your credentials to login.</p>

        <?php 
        if(isset($_SESSION["error"])){
            $error_print = $_SESSION["error"];
            echo '<div class="alert alert-danger">' . $$error_print . '</div>';
        }        
        ?>

        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <div class="form-group">
                <label>Username</label>
                <input type="text" name="username" id="username" placeholder="Username">
            </div>    
            <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" class="form-control <?php echo (!empty($password_err)) ? 'is-invalid' : ''; ?>">
                <span class="invalid-feedback"><?php echo $password_err; ?></span>
            </div>
            <div class="form-group">
                <input type="submit" class="btn btn-primary" value="Login">
            </div>
        </form>
    </div>
</body>
</html>

<?php 
  unset($_SESSION["error"]);
?>