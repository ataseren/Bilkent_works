<?php

if(!defined('host')) define('host','dijkstra.ug.bcc.bilkent.edu.tr' );
if(!defined('dbname')) define('dbname','ata_seren' );
if(!defined('username')) define('username','ata.seren' );
if(!defined('password')) define('password','KQVDZMy9' );

$connection = mysqli_connect(host, username, password, dbname);


if($connection->connect_errno) {
    echo "Failed to connect to MySQL: (". mysqli_connect_errno(). ") ". mysqli_connect_error();
}

    
?>