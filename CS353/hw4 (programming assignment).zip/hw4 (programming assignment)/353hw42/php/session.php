<?php
include('config.php');
session_start();
$user_check = $_SESSION['login_user'];
$query = "select sname from student where sname = '$user_check'";
$result = $mysqli->query($query);
$row = $result->fetch_array(MYSQLI_ASSOC);
$login_session = $row['sname'];

if(!isset($_SESSION['login_user'])){
    header("location: index.php");
}

?>