<?php

	session_start();

	require_once "config.php";

	include "templates/header.php";

	if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === false){
	    header("location: index.php");
	    exit;
	}

	if(isset($_POST["logoutButton"])){
		session_destroy();
		header("location: index.php");
		exit;
	}

	if(isset($_POST["previousPage"])){
		header("location: index.php");
		exit;
	}

	if(isset($_POST["applyToCompanyButton"])){
		$companyIsSuitableForAppliction = mysqli_query($link, "SELECT * FROM (SELECT * FROM company WHERE quota != 0 AND cid NOT IN (SELECT cid FROM apply WHERE sid='" . $_SESSION['sid'] . "')) AS c WHERE c.cid = '" . $_POST["applyCID"] . "'");
		if($companyIsSuitableForAppliction){
			$_SESSION["applied"] = mysqli_query($link, "INSERT INTO apply values('" . $_POST['applyCID'] . "', '" . $_SESSION['sid'] . "')");
			header("location: application.php");
			exit;
		}
		else{
			echo "<script type='text/javascript'>alert('Please enter a valid company ID.');</script>";
		}
	}

	if(isset($_SESSION["applied"])){
		if($_SESSION["applied"] == true){
			echo "<script type='text/javascript'>alert('Successfully applied.');</script>";
		}
		else{
			echo "<script type='text/javascript'>alert('Could not apply. Try again.');</script>";
		}
		unset($_SESSION["applied"]);
	}
?>


<h3>You can see the companies to apply below.</h3><br>
<div class = "companylist">
	<div>
		<form method="POST">
			<input type="text" name="applyCID" id="applyCID" placeholder="Company ID to apply.">
			<input type="submit" class="button" name="applyToCompanyButton" id="applyToCompanyButton" value="Submit">
		</form>
	</div>
	<table>
		<tr>
		  <th>Company ID</th>
		  <th>Company Name</th> 
		  <th>Quota</th>
		</tr>
		<?php 
			if($link){
				$companyTableToApply = mysqli_query($link, "SELECT * FROM company WHERE quota != 0 AND cid NOT IN (SELECT cid FROM apply WHERE sid='" . $_SESSION['sid'] . "')");
				while($record = mysqli_fetch_array($companyTableToApply)){
					echo "<tr>";
					echo "<td>" . $record['cid'] . "</td>";
					echo "<td>" . $record['cname'] . "</td>";
					echo "<td>" . $record['quota'] . "</td>";
					echo "</tr>";
				}
			}
		?>
	</table>
	<div>
		<form method="POST">
			<input type="submit" class="button" name="previousPage" id="previousPage" value="Go back to previous page.">
			<input type="submit" class="button" name="logoutButton" id="logoutButton" value="Logout from system">
		</form>
	</div>
</div>