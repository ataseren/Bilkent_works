<?php

	session_start();

	require_once "config.php";

	include "templates/header.php";

	if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === false){
	    header("location: index.php");
	    exit;
	}

	if(isset($_POST["cancel"])){
		$_SESSION["cancel"] = mysqli_query($link, "DELETE FROM apply WHERE cid='" . $_POST['companyID'] . "' AND sid='" . $_SESSION['sid'] . "'");
		mysqli_query($link, "UPDATE company SET quota = quota + 1 WHERE cid='" . $_POST['companyID'] . "'");
		header("location: welcome.php");
	    exit;
	}

	if(isset($_SESSION["cancel"])){
		if($_SESSION["cancel"] == true){
			echo "<script type='text/javascript'>alert('Application successfully canceled.');</script>";
		}
		else{
			echo "<script type='text/javascript'>alert('Application can not be canceled.');</script>";
		}
		unset($_SESSION["cancel"]);
	}

	if(isset($_POST["applyButton"])){
		$applyCountQuery = mysqli_query($link, "SELECT * FROM apply WHERE sid ='" . $_SESSION['sid'] . "'" );
		$applyCount = 0;
		while(mysqli_fetch_array($applyCountQuery)){
			$applyCount++;
		}
		if($applyCount == 3){
			echo "<script type='text/javascript'>alert('You have already 3 applications. You can not apply for anymore.');</script>";
		}
		else{
			header("location: application.php");
			exit;
		}
	}

	if(isset($_POST["logoutButton"])){
		session_destroy();
		header("location: index.php");
		exit;
	}

?>

<?php 
	echo "<h2> Welcome " . $_SESSION['sname'] . " with student ID " . $_SESSION['sid'] . "</h2>";
?>
<h3>You can find the companies you applied for internships below.</h3><br>
<div class = "companylist">
	<table>
		<tr>
		  <th>Company ID</th>
		  <th>Company Name</th> 
		  <th>Quota</th>
		  <th> </th>
		</tr>
		<?php 
			if($link){
				$applyTable = mysqli_query($link, "SELECT * FROM apply WHERE sid ='" . $_SESSION['sid'] . "'" );
				while($applyRecord = mysqli_fetch_array($applyTable)){
					$companyTable = mysqli_query($link, "SELECT * FROM company WHERE cid ='" . $applyRecord['cid'] . "'");
					$companyRecord = mysqli_fetch_array($companyTable);
					echo "<tr>";
					echo "<td>" . $companyRecord['cid'] . "</td>";
					echo "<td>" . $companyRecord['cname'] . "</td>";
					echo "<td>" . $companyRecord['quota'] . "</td>";
					echo "<td>" . "<form method='POST'><input type='text' name='companyID' hidden='' value='". $companyRecord['cid'] ."'><input type='submit' class='button' name='cancel' id='cancel' value='Cancel'></form>" . "</td>";
					echo "</tr>";
				}
			}
		?>
	</table>
	<div>
		<form method="POST">
			<input type="submit" class="button" name="applyButton" id="applyButton" value="Apply For Internships">
			<input type="submit" class="button" name="logoutButton" id="logoutButton" value="Logout from system">
		</form>
	</div>
</div>
