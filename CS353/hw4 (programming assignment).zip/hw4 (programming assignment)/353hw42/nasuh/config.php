<?php

define('DB_SERVER', 'dijkstra.ug.bilkent.edu.tr');
define('DB_USERNAME', 'nasuh.dincer');
define('DB_PASSWORD', 'Po3bz3uI');
define('DB_NAME', 'nasuh_dincer');
 
/* Attempt to connect to MySQL database */
$link = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
?>