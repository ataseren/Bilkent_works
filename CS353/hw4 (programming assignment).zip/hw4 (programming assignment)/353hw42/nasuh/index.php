<?php

  session_start();

  include "templates/header.php";
   
  if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true){
      header("location: welcome.php");
      exit;
  }

  require_once "config.php";
   
  $loginError = "Log-on operation failed. Please check username and password and try again.";

  if(isset($_POST["log"])){
    $loginQuery = mysqli_query($link, "SELECT sname FROM student WHERE sid = '" . $_POST['password'] . "'");
    if(!$loginQuery){
      $_SESSION["error"] = $loginError;
      header("location: index.php");
      exit;
    }
    else{
      $record = mysqli_fetch_array($loginQuery);
      if($record["sname"] == $_POST["username"]){
        $_SESSION["loggedin"] = true;
        $_SESSION["sname"] = $_POST["username"];
        $_SESSION["sid"] = $_POST["password"];
        header("location: welcome.php");
        exit;
      }
      else{
        $_SESSION["error"] = $loginError;
        header("location: index.php");
        exit;
      }
    }
  }

?>

<h2>Login Page</h2><br>
<div class = "login">
<form id="login" method="post">
    <label>
      <b>Name</b>
    </label>
    <input type="text" name="username" id="username" placeholder="Username">

    <br><br>
    <label>
      <b>Password</b>
    </label>
    <input type="Password" name="password" id="password" placeholder="Password">
    <br><br>
    <input type="submit" name="log" id="log" value="Login">
    <br><br>
    <?php
      if(isset($_SESSION["error"])){
        $error = $_SESSION["error"];
        echo "<span>$error</span>";
      }
    ?>
    <br><br>
</form> 
</div>

<?php 
  include "templates/footer.php";
  unset($_SESSION["error"]);
?>