import java.sql.*;

public class dbChanger{
    public static void main(String[] args) 
    {
        Connection conn = null;
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            System.out.println("Driver loaded");
            conn = DriverManager.getConnection("jdbc:mysql://dijkstra.ug.bcc.bilkent.edu.tr/ata_seren", "ata.seren","KQVDZMy9");
            System.out.println("Connected successfully");
        }catch(Exception e)
        {
            e.printStackTrace();
        }

        Statement stmt = null;
        String studentTable = "CREATE TABLE student(" +
        "sid CHAR(12)," +
        "sname VARCHAR(50)," +
        "bdate DATE," +
        "address VARCHAR(50)," +
        "scity VARCHAR(20)," +
        "year CHAR(20)," +
        "gpa FLOAT," +
        "nationality VARCHAR(20)," +
        "PRIMARY KEY(sid)) ENGINE=innodb;";

        String companyTable = "CREATE TABLE company(" +
        "cid CHAR(8)," +
        "cname VARCHAR(20)," +
        "quota INT," +
        "gpathreshold FLOAT," +
        "PRIMARY KEY(cid)) ENGINE=innodb;";

        String applyTable = "CREATE TABLE apply(" +
        "sid CHAR(12)," +
        "cid CHAR(8)," +
        "PRIMARY KEY(sid, cid)," +
        "FOREIGN KEY (sid) REFERENCES student(sid), "
        + "FOREIGN KEY (cid) REFERENCES company(cid))" + "ENGINE=innodb;";
        
        try{
            stmt = conn.createStatement();
            stmt.executeUpdate("DROP TABLE apply");
            stmt = conn.createStatement();
            stmt.executeUpdate("DROP TABLE student");
            stmt = conn.createStatement();
            stmt.executeUpdate("DROP TABLE company");
            
            
            stmt = conn.createStatement();
            stmt.executeUpdate(studentTable);
            System.out.println("Table student created");
            stmt = conn.createStatement();
            stmt.executeUpdate(companyTable);
            System.out.println("Table company created");
            stmt = conn.createStatement();
            stmt.executeUpdate(applyTable);
            System.out.println("Table apply created");
        }catch(Exception e)
        {
            System.out.println("Table creation has failed");
            e.printStackTrace();
        }

        try{
            stmt = conn.createStatement();
            stmt.executeUpdate("INSERT INTO student VALUES ('21000001', 'Marco', '1998-05-31', 'Strobelallee', 'Dortmund', 'senior', 2.64, 'DE')");
            stmt = conn.createStatement();
            stmt.executeUpdate("INSERT INTO student VALUES ('21000002', 'Arif', '2001-11-17', 'Nisantasi', 'Istanbul', 'junior', 3.86, 'TC')");
            stmt = conn.createStatement();
            stmt.executeUpdate("INSERT INTO student VALUES ('21000003', 'Veli', '2003-02-19', 'Cayyolu', 'Ankara', 'freshman', 2.21, 'TC')");
            stmt = conn.createStatement();
            stmt.executeUpdate("INSERT INTO student VALUES ('21000004', 'Ayse', '2003-05-01', 'Tunali', 'Ankara', 'freshman', 2.52, 'TC')");
            stmt = conn.createStatement();
            stmt.executeUpdate("INSERT INTO company VALUES ('C101', 'milsoft', 3, 2.50)");
            stmt = conn.createStatement();
            stmt.executeUpdate("INSERT INTO company VALUES ('C102', 'merkez bankasi', 10, 2.45)");
            stmt = conn.createStatement();
            stmt.executeUpdate("INSERT INTO company VALUES ('C103', 'tubitak', 2, 3.00)");
            stmt = conn.createStatement();
            stmt.executeUpdate("INSERT INTO company VALUES ('C104', 'havelsan', 5, 2.00)");
            stmt = conn.createStatement();
            stmt.executeUpdate("INSERT INTO company VALUES ('C105', 'aselsan', 4, 2.50)");
            stmt = conn.createStatement();
            stmt.executeUpdate("INSERT INTO company VALUES ('C106', 'tai', 2, 2.20)");
            stmt = conn.createStatement();
            stmt.executeUpdate("INSERT INTO company VALUES ('C107', 'amazon', 1, 3.85)");
            stmt = conn.createStatement();
            stmt.executeUpdate("INSERT INTO apply VALUES ('21000001', 'C101')");
            stmt = conn.createStatement();
            stmt.executeUpdate("INSERT INTO apply VALUES ('21000001', 'C102')");
            stmt = conn.createStatement();
            stmt.executeUpdate("INSERT INTO apply VALUES ('21000001', 'C104')");
            stmt = conn.createStatement();
            stmt.executeUpdate("INSERT INTO apply VALUES ('21000002', 'C107')");
            stmt = conn.createStatement();
            stmt.executeUpdate("INSERT INTO apply VALUES ('21000003', 'C104')");
            stmt = conn.createStatement();
            stmt.executeUpdate("INSERT INTO apply VALUES ('21000003', 'C106')");
            stmt = conn.createStatement();
            stmt.executeUpdate("INSERT INTO apply VALUES ('21000004', 'C102')");
            stmt = conn.createStatement();
            stmt.executeUpdate("INSERT INTO apply VALUES ('21000004', 'C106')");
            
        }catch(Exception e)
        {
            System.out.println("Insertions have failed");
            e.printStackTrace();
        }

        String q1 = "SELECT sname FROM student NATURAL JOIN company NATURAL JOIN apply GROUP BY sname HAVING count(*) = 3";

        String q2 = "SELECT sum(quota) AS qsum FROM student NATURAL JOIN company NATURAL JOIN apply WHERE sid = " +
        "(SELECT sid FROM (SELECT sid, count(*) AS cnt FROM apply GROUP BY sid) AS intable ORDER BY cnt DESC LIMIT 1)";

        String q3 =  "SELECT avg(cnt), nationality FROM (SELECT sid, nationality, count(*) AS cnt FROM student NATURAL JOIN apply GROUP BY sid) AS intable " +
        "GROUP BY nationality";

        String q4 = "SELECT cmp.cname FROM company AS cmp WHERE NOT EXISTS((SELECT std.sid FROM student AS std WHERE std.year = 'freshman' AND " + 
                    " std.sid NOT IN (SELECT app.sid FROM apply AS app WHERE app.cid = cmp.cid)))"; 

        String q5 = "SELECT cname, avg(gpa) as avggpa FROM student NATURAL JOIN company NATURAL JOIN apply GROUP BY cname";


        try{
            stmt = conn.createStatement();
            ResultSet rs1 = stmt.executeQuery(q1);
            System.out.println("Question 1");
            System.out.println("");
            System.out.printf("%10s", "sname" );
            System.out.println("");
            System.out.println("---------------");
            System.out.println("");
            while(rs1.next()){
                System.out.printf("%12s", rs1.getString(1));
                System.out.println("");
            }
            System.out.println("");
        }
        catch(Exception e)
        {
            System.out.println("Query 1 failed");
            e.printStackTrace();
        }

        try{
            stmt = conn.createStatement();
            ResultSet rs2 = stmt.executeQuery(q2);
            System.out.println("Question 2");
            System.out.println("");
            System.out.printf("%10s", "qsum" );
            System.out.println("");
            System.out.println("---------------");
            System.out.println("");
            while(rs2.next()){
                System.out.printf("%10s", rs2.getInt(1));
                System.out.println("");
            }
            System.out.println("");
        }
        catch(Exception e)
        {
            System.out.println("Query 2 failed");
            e.printStackTrace();
        }

        try{
            stmt = conn.createStatement();
            ResultSet rs3 = stmt.executeQuery(q3);
            System.out.println("Question 3");
            System.out.println("");
            System.out.printf("%10s%15s", "avg", "nationality");
            System.out.println("");
            System.out.println("----------------------------------");
            System.out.println("");
            while(rs3.next()){
                System.out.printf("%10s%15s", rs3.getInt(1), rs3.getString(2));
                System.out.println("");
            }
            System.out.println("");
        }
        catch(Exception e)
        {
            System.out.println("Query 3 failed");
            e.printStackTrace();
        }

        try{
            stmt = conn.createStatement();
            ResultSet rs4 = stmt.executeQuery(q4);
            System.out.println("Question 4");
            System.out.println("");
            System.out.printf("%10s", "cname");
            System.out.println("");
            System.out.println("-----------------");
            System.out.println("");
            while(rs4.next()){
                System.out.printf("%10s", rs4.getString(1));
                System.out.println("");
            }
            System.out.println("");
        }
        catch(Exception e)
        {
            System.out.println("Query 4 failed");
            e.printStackTrace();
        }

        try{
            stmt = conn.createStatement();
            ResultSet rs5 = stmt.executeQuery(q5);
            System.out.println("Question 5");
            System.out.println("");
            System.out.printf("%15s%15s", "cname", "avggpa");
            System.out.println("");
            System.out.println("---------------------------------");
            System.out.println("");
            while(rs5.next()){
                System.out.printf("%15s%15s", rs5.getString(1), Math.round(rs5.getDouble(2)*100.0)/100.0);
                System.out.println("");
            }
            System.out.println("");
        }
        catch(Exception e)
        {
            System.out.println("Query 5 failed");
            e.printStackTrace();
        }

    }
}