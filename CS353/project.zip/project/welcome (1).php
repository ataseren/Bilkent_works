<?php

    session_start();

    require_once "config.php";

    $course_id = "";

    if (isset($_SESSION["loginStat"]) && $_SESSION["loginStat"] === false) {
        header("location: index.php");
        exit;
    }

    /*if (isset($_POST["cancel"])) {
        $_SESSION["cancel"] = mysqli_query($connection, "DELETE FROM apply WHERE cid='" . $_POST['companyID'] . "' AND sid='" . $_SESSION['sid'] . "'");
        mysqli_query($connection, "UPDATE company SET quota = quota + 1 WHERE cid='" . $_POST['companyID'] . "'");
        header("location: welcome.php");
        exit;
    }*/

    /*if (isset($_SESSION["cancel"])) {
        if ($_SESSION["cancel"] == true) {
            echo "<script type='text/javascript'>alert('Application has been cancelled.');</script>";
        } else {
            echo "<script type='text/javascript'>alert('Application can not be cancelled due to unknown error.');</script>";
        }
        unset($_SESSION["cancel"]);
    }*/

    if (isset($_POST["applyCourse"])) {
        $studentCourses = mysqli_query($connection, "SELECT * FROM apply WHERE sid ='" . $_SESSION['sid'] . "'"); //query change
		
        header("location: apply.php");
		exit;
    }

    if (isset($_POST["logout"])) {
        session_destroy();
        header("location: index.php");
        exit;
    }

    if (isset($_POST["go"])) {
        $_SESSION["course_id"] = $_POST['id'];
        header("location: course.php");
        exit;
    }

?>

<?php 
	echo "<h2> Hello " . $_SESSION['sname']. ". Welcome to Online Language Learning Platform.</h2>";
    echo "<h3>Your language courses: </h3><br>";
?>

<!DOCTYPE html>
<html lang="en">
<head>  

<link rel="stylesheet" href="design.css">   

</head>  
<div class="applied">
    <table>
        <tr>
            <th>Course Language</th>
            <th>Course Level</th>
            <th>Course Teacher</th>
            <th>Go to the Course Page</th>
        </tr>
        
        <?php
        if ($connection) {
            $appliedTable = mysqli_query($connection, "SELECT * FROM enroll WHERE user_id = 1"); /*'". $_SESSION['sid'] . "'"); //change query*/
            while ($appliedData = mysqli_fetch_array($appliedTable)) {
                $courseData = mysqli_query($connection, "SELECT * FROM course WHERE course_id ='" . $appliedData['course_id'] . "'");
                $appliedCourses = mysqli_fetch_array($courseData);

                $teachData = mysqli_query($connection, "SELECT * FROM teach WHERE course_id ='" . $appliedCourses['course_id'] . "'");
                $data = mysqli_fetch_array($teachData);

                $teachers = mysqli_query($connection, "SELECT * FROM user WHERE user_id ='" . $data['user_id'] . "'");
                $teacher = mysqli_fetch_array($teachers);


                //$course_id = $appliedCourses['course_id'];
                echo "<tr>";
                //echo $appliedCourses['course_id'] ;
                echo "<td>" . $appliedCourses['course_language'] . "</td>";
                echo "<td>" . $appliedCourses['course_level'] . "</td>";
                echo "<td>" . $teacher['first_name'] . " " . $teacher['last_name'] ."</td>";
                //echo "<td>" . "<form method='POST'><input type='text' name='course_id' hidden='' value='" . $appliedCourses['course_id'] . "'><input type='submit' class='button' name='go' id='go' value='Go to the Course Page'></form>" . "</td>";
                echo "<td>" . "<form method='POST'> <input type='submit' class='button' value='Go to the Course Page' name='go' id='go'> <input type='hidden' name='id' value='" . $appliedCourses['course_id'] . "'> </form>" . "</td>";
                //echo "<td>" . "<form method='POST'> <input type='submit' class='button' value='" . $appliedCourses['course_id'] . "' name='Go' id='go'>  <input type='hidden' name='id' value='" . $appliedCourses['course_id'] . "'> </form>" . "</td>";
                echo "</tr>";
            }
        }
        ?>

    </table>

        <form method="POST">
            <input type="submit" class="button" name="application" id="application" value="Apply">
            <input type="submit" class="button" name="logout" id="logout" value="Logout">
        </form>


    <?php 
        if(isset($_SESSION["apply"])){
            $applyLimitWarning = $_SESSION["apply"];
            echo '<div class="alert">' . $applyLimitWarning . '</div>';
        }        
    ?>
</div>
</html>

<?php 
  unset($_SESSION["apply"]);
?>