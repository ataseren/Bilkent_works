<?php

session_start();


if (isset($_SESSION["loginStat"]) && $_SESSION["loginStat"] === true) {
    header("location: welcome.php");
    exit;
}

require_once "config.php";

//Variable definitions 
$username = "";
$password = "";
$username_err = "";
$password_err = "";
$login_err = "Invalid username or password.";

// Processing form data when form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Check if username is empty
    if (empty(trim($_POST["username"]))) {
        $username_err = "Enter your username here.";
    } else {
        $username = trim($_POST["username"]);
    }

    // Check if password is empty
    if (empty(trim($_POST["password"]))) {
        $password_err = "Enter your ID (password) here.";
    } else {
        $password = trim($_POST["password"]);
    }

    // Validate credentials
    if (empty($username_err) && empty($password_err)) {
        // Prepare a select statement
        $query = mysqli_query($connection, "SELECT sname FROM student WHERE sid = '" . $_POST['password'] . "'");
        if (!$query) {
            $_SESSION["error"] = $login_err;
            header("location: index.php");
            exit;
        } else {

            $dbData = mysqli_fetch_array($query);
            if ($dbData["sname"] == $_POST["username"]) {
                $_SESSION["loginStat"] = true;
                $_SESSION["sname"] = $_POST["username"];
                $_SESSION["sid"] = $_POST["password"];
                header("location: welcome.php");
                exit;
            } else {
                $_SESSION["error"] = $login_err;
                header("location: index.php");
                exit;
            }
        }
    }

    // Close connection
    mysqli_close($connection);
}
?>

<!DOCTYPE html>
<html lang="en">

<head>  

<link rel="stylesheet" href="design.css">   

</head>  

<body>
    <div class="login">
        <h1>Welcome to Online Language Learning Platform</h1>
        <h3>Please fill in your credentials to login.</h3>

        <?php 
        if(isset($_SESSION["error"])){
            $error_print = $_SESSION["error"];
            echo '<div class="alert">' . $error_print . '</div>';
        }        
        ?>

        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
            <div class="form-group">
                <label>Username</label>
                <input type="text" name="username" id="username" class="form-control <?php echo (!empty($username_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $username; ?>">
                <span class="invalid-feedback"><?php echo $username_err; ?>
            </div>
            <br>
            <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" id="password" class="form-control <?php echo (!empty($password_err)) ? 'is-invalid' : ''; ?>">
                <span class="invalid-feedback"><?php echo $password_err; ?></span>
            </div>
            <br>
            <div class="form-group">
                <input type="submit" name ="loginButton" id ="loginButton" class="btn btn-primary" value="Login">
            </div>
        </form>
    </div>
</body>
</html>

<?php 
  unset($_SESSION["error"]);
?>